package com.astramesh.app.network

import com.astramesh.app.crypto.CryptoManager
import com.astramesh.app.crypto.Identity
import com.google.gson.Gson
import com.google.gson.JsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

class RelayClient(private val url: String) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
        
    private var webSocket: WebSocket? = null
    private val gson = Gson()
    
    var onConnected: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onMessageReceived: ((from: String, ciphertext: String, nonce: String, signature: String) -> Unit)? = null
    
    private var identity: Identity? = null
    
    fun connect(identity: Identity) {
        this.identity = identity
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, RelayWebSocketListener())
    }
    
    fun disconnect() {
        webSocket?.close(1000, null)
        webSocket = null
    }
    
    fun sendMessage(to: String, ciphertext: String, nonce: String, signature: String) {
        val payload = JsonObject().apply {
            addProperty("type", "message")
            addProperty("to", to)
            addProperty("ciphertext", ciphertext)
            addProperty("nonce", nonce)
            addProperty("signature", signature)
        }
        webSocket?.send(payload.toString())
    }

    private inner class RelayWebSocketListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            // Wait for challenge
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            val json = gson.fromJson(text, JsonObject::class.java)
            val type = json.get("type")?.asString ?: return

            when (type) {
                "challenge" -> {
                    val nonceStr = json.get("nonce").asString
                    val nonceBytes = CryptoManager.fromHex(nonceStr)
                    val signature = CryptoManager.sign(nonceBytes, identity!!.signingSecretKey)
                    
                    val authPayload = JsonObject().apply {
                        addProperty("type", "auth")
                        addProperty("publicKey", CryptoManager.toHex(identity!!.signingPublicKey))
                        addProperty("signature", CryptoManager.toHex(signature))
                    }
                    webSocket.send(authPayload.toString())
                }
                "auth_ok" -> {
                    onConnected?.invoke()
                }
                "message" -> {
                    val from = json.get("from").asString
                    val ciphertext = json.get("ciphertext").asString
                    val nonce = json.get("nonce").asString
                    val signature = json.get("signature").asString
                    
                    onMessageReceived?.invoke(from, ciphertext, nonce, signature)
                }
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            onDisconnected?.invoke()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            onDisconnected?.invoke()
        }
    }
}
