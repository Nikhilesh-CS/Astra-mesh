package com.astramesh.app.crypto

import android.util.Base64
import com.goterl.lazysodium.LazySodiumAndroid
import com.goterl.lazysodium.SodiumAndroid
import com.goterl.lazysodium.interfaces.Box
import com.goterl.lazysodium.interfaces.Sign
import com.goterl.lazysodium.utils.Key
import com.goterl.lazysodium.utils.KeyPair
import com.google.gson.Gson
import org.json.JSONObject

data class Identity(
    val name: String,
    val encryptionPublicKey: ByteArray,
    val encryptionSecretKey: ByteArray,
    val signingPublicKey: ByteArray,
    val signingSecretKey: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Identity
        return name == other.name &&
                encryptionPublicKey.contentEquals(other.encryptionPublicKey) &&
                encryptionSecretKey.contentEquals(other.encryptionSecretKey) &&
                signingPublicKey.contentEquals(other.signingPublicKey) &&
                signingSecretKey.contentEquals(other.signingSecretKey)
    }
    override fun hashCode(): Int {
        var result = name.hashCode()
        result = 31 * result + encryptionPublicKey.contentHashCode()
        result = 31 * result + encryptionSecretKey.contentHashCode()
        result = 31 * result + signingPublicKey.contentHashCode()
        result = 31 * result + signingSecretKey.contentHashCode()
        return result
    }
}

object CryptoManager {
    private val lazySodium = LazySodiumAndroid(SodiumAndroid())
    private val gson = Gson()

    fun generateIdentity(name: String): Identity {
        val encKeyPair = lazySodium.cryptoBoxKeypair()
        val sigKeyPair = lazySodium.cryptoSignKeypair()

        return Identity(
            name = name,
            encryptionPublicKey = encKeyPair.publicKey.asBytes,
            encryptionSecretKey = encKeyPair.secretKey.asBytes,
            signingPublicKey = sigKeyPair.publicKey.asBytes,
            signingSecretKey = sigKeyPair.secretKey.asBytes
        )
    }

    fun encryptMessage(plaintext: String, recipientEncPub: ByteArray, senderEncSec: ByteArray): Pair<ByteArray, ByteArray> {
        val nonce = lazySodium.nonce(Box.NONCEBYTES)
        val ciphertext = ByteArray(plaintext.toByteArray(Charsets.UTF_8).size + Box.MACBYTES)
        
        val success = lazySodium.cryptoBoxEasy(
            ciphertext,
            plaintext.toByteArray(Charsets.UTF_8),
            plaintext.toByteArray(Charsets.UTF_8).size.toLong(),
            nonce,
            recipientEncPub,
            senderEncSec
        )
        
        if (!success) throw Exception("Encryption failed")
        return Pair(ciphertext, nonce)
    }

    fun decryptMessage(ciphertext: ByteArray, nonce: ByteArray, senderEncPub: ByteArray, recipientEncSec: ByteArray): String {
        val plaintext = ByteArray(ciphertext.size - Box.MACBYTES)
        
        val success = lazySodium.cryptoBoxOpenEasy(
            plaintext,
            ciphertext,
            ciphertext.size.toLong(),
            nonce,
            senderEncPub,
            recipientEncSec
        )
        
        if (!success) throw Exception("Decryption failed")
        return String(plaintext, Charsets.UTF_8)
    }

    fun sign(data: ByteArray, secretKey: ByteArray): ByteArray {
        val signature = ByteArray(Sign.BYTES)
        val success = lazySodium.cryptoSignDetached(
            signature,
            data,
            data.size.toLong(),
            secretKey
        )
        if (!success) throw Exception("Signing failed")
        return signature
    }

    fun verify(data: ByteArray, signature: ByteArray, publicKey: ByteArray): Boolean {
        return lazySodium.cryptoSignVerifyDetached(
            signature,
            data,
            data.size.toLong(),
            publicKey
        )
    }

    fun createContactString(identity: Identity): String {
        val json = JSONObject().apply {
            put("n", identity.name)
            put("e", lazySodium.toHex(identity.encryptionPublicKey).lowercase())
            put("s", lazySodium.toHex(identity.signingPublicKey).lowercase())
        }
        val b64 = Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        return "astra:$b64"
    }

    fun parseContactString(contactString: String): Triple<String, ByteArray, ByteArray>? {
        try {
            val prefix = "astra:"
            if (!contactString.startsWith(prefix)) return null
            
            val b64 = contactString.removePrefix(prefix).trim()
            val jsonString = String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8)
            val json = JSONObject(jsonString)
            
            val name = json.getString("n")
            val encPub = lazySodium.sodiumHex2Bin(json.getString("e"))
            val sigPub = lazySodium.sodiumHex2Bin(json.getString("s"))
            
            return Triple(name, encPub, sigPub)
        } catch (e: Exception) {
            return null
        }
    }
    
    fun toHex(bytes: ByteArray): String = lazySodium.toHex(bytes).lowercase()
    fun fromHex(hex: String): ByteArray = lazySodium.sodiumHex2Bin(hex)
}
