package com.astramesh.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.astramesh.app.ui.theme.AstraMeshTheme
import com.astramesh.app.identity.IdentityManager
import com.astramesh.app.ui.screens.*

class MainActivity : ComponentActivity() {
    private lateinit var identityManager: IdentityManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identityManager = IdentityManager(this)
        
        setContent {
            AstraMeshTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val hasIdentity = remember { identityManager.hasIdentity() }
                    
                    NavHost(
                        navController = navController, 
                        startDestination = if (hasIdentity) "chatList" else "setup"
                    ) {
                        composable("setup") {
                            SetupScreen(
                                identityManager = identityManager,
                                onIdentityCreated = { navController.navigate("chatList") {
                                    popUpTo("setup") { inclusive = true }
                                } }
                            )
                        }
                        composable("chatList") {
                            ChatListScreen(
                                identityManager = identityManager,
                                navController = navController
                            )
                        }
                        composable("chat/{contactKey}") { backStackEntry ->
                            val contactKey = backStackEntry.arguments?.getString("contactKey") ?: return@composable
                            ChatScreen(
                                contactKey = contactKey,
                                identityManager = identityManager,
                                navController = navController
                            )
                        }
                    }
                }
            }
        }
    }
}
