package com.astramesh.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.astramesh.app.crypto.CryptoManager
import com.astramesh.app.data.AppDatabase
import com.astramesh.app.data.ContactEntity
import com.astramesh.app.identity.IdentityManager
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    identityManager: IdentityManager,
    navController: NavController
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showAddDialog by remember { mutableStateOf(false) }
    var contacts by remember { mutableStateOf<List<ContactEntity>>(emptyList()) }
    
    val db = remember {
        Room.databaseBuilder(context, AppDatabase::class.java, "astra-mesh-db").build()
    }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            contacts = db.contactDao().getAllContacts()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Astra Mesh") },
                actions = {
                    IconButton(onClick = {
                        val identity = identityManager.loadIdentity()
                        if (identity != null) {
                            val contactString = CryptoManager.createContactString(identity)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Contact String", contactString)
                            clipboard.setPrimaryClip(clip)
                        }
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = "Copy Contact String")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add Contact")
            }
        }
    ) { paddingValues ->
        if (contacts.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                Text("No Contacts Yet", color = Color.Gray)
            }
        } else {
            LazyColumn(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
                items(contacts) { contact ->
                    ContactRow(contact) {
                        navController.navigate("chat/${contact.signingPublicKey}")
                    }
                }
            }
        }

        if (showAddDialog) {
            AddContactDialog(
                onDismiss = { showAddDialog = false },
                onContactAdded = { contactStr ->
                    coroutineScope.launch {
                        val parsed = CryptoManager.parseContactString(contactStr)
                        if (parsed != null) {
                            val (name, encPub, sigPub) = parsed
                            val contact = ContactEntity(
                                name = name,
                                encryptionPublicKey = CryptoManager.toHex(encPub),
                                signingPublicKey = CryptoManager.toHex(sigPub)
                            )
                            withContext(Dispatchers.IO) {
                                db.contactDao().insertContact(contact)
                                contacts = db.contactDao().getAllContacts()
                            }
                            showAddDialog = false
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun ContactRow(contact: ContactEntity, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = contact.name.take(1).uppercase(),
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = contact.name,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}
