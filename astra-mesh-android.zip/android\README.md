# Astra Mesh - Android Client (Phase 1)

This is the native Android client for Astra Mesh, built with Kotlin and Jetpack Compose. It connects to the Node.js relay server for E2E encrypted messaging.

## Prerequisites
- Android Studio Iguana (or newer)
- Android SDK 34

## Build and Run
1. Open Android Studio.
2. Select **Open** and choose the `astra-mesh/android/` directory.
3. Android Studio will sync the Gradle project automatically.
4. Select an Android Emulator (API 26+) or connect a physical device.
5. Click **Run** (Shift + F10).

## Relay URL Configuration
The default relay URL in `RelayClient.kt` or `MainActivity.kt` may need to be adjusted depending on how you're running the server:
- If testing on the Android Emulator and the relay is running on your host machine: use `ws://10.0.2.2:3000`
- If testing on a physical device on your local Wi-Fi: use the host machine's local IP address, e.g. `ws://192.168.1.5:3000`

## Testing E2E Encryption
1. Start the relay server (`npm start` in the `relay` directory).
2. Install the app on an Android Emulator.
3. In a browser, open `http://localhost:3000/inspect` to monitor the relay queue.
4. Create an identity, view your Contact Key in the app, and exchange it with another client (e.g. iOS or another Android instance).
5. Send encrypted messages and observe the ciphertexts on the relay's `/inspect` endpoint.
