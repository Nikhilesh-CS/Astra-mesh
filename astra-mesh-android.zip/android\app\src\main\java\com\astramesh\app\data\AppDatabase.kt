package com.astramesh.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val signingPublicKey: String,
    val encryptionPublicKey: String,
    val name: String
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val messageId: String,
    val contactKey: String,
    val text: String,
    val timestamp: Long,
    val direction: String
)

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts")
    fun getAllContacts(): List<ContactEntity>

    @Insert
    fun insertContact(contact: ContactEntity)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE contactKey = :contactKey ORDER BY timestamp ASC")
    fun getMessagesForContact(contactKey: String): List<MessageEntity>

    @Insert
    fun insertMessage(message: MessageEntity)
}

@Database(entities = [ContactEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun messageDao(): MessageDao
}
